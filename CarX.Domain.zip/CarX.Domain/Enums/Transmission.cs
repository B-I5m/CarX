namespace CarX.Domain.Enums;

public class Transmission
{
    
}