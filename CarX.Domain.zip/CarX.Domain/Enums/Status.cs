namespace CarX.Domain.Enums;

public enum CarStatus
{
    PendingModeration = 0, // Ожидает проверки админом
    Active = 1,            // Опубликовано
    Sold = 2,              // Продано
    Rejected = 3,          // Отклонено модератором
    Archived = 4           // В архиве
}