namespace CarX.Domain.Enums;

public enum UserRole
{
    Buyer = 0,      // Покупатель
    Seller = 1,     // Продавец
    Moderator = 2,  // Модератор (может проверять авто)
    Admin = 3       // Администратор (полный доступ)
}