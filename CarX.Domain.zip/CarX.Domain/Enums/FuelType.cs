namespace CarX.Domain.Enums;

public enum FuelType
{
    Petrol = 0,   // Бензин
    Diesel = 1,   // Дизель
    Electric = 2, // Электро
    Hybrid = 3,   // Гибрид
    Gas = 4       // Газ
}