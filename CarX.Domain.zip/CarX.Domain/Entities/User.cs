using CarX.Domain.Common;
using CarX.Domain.Enums;

namespace CarX.Domain.Entities;

public class User : BaseEntity
{
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PhoneNumber { get; set; } = string.Empty;
    public int Role { get; set; }

    public ICollection<Car> Cars { get; set; } = new List<Car>();
}