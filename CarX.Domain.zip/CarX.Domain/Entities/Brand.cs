using System.Collections.Generic;

namespace CarX.Domain.Entities
{
    public class Brand
    {
        public long Id { get; set; } // long ID
        public string Name { get; set; }
        public string BrandImage { get; set; } // Твое поле для картинки бренда
        
        // Navigation property
        public virtual ICollection<Car> Cars { get; set; } = new List<Car>();
    }
}