namespace CarX.Domain.Entities
{
    public enum CarClass 
    { 
        Economy, 
        Standard, 
        Business 
    }

    public class Car
    {
        public long Id { get; set; } // long ID
        public string Model { get; set; }
        public int Year { get; set; }
        public decimal Price { get; set; }
        public CarClass Class { get; set; } // Эконом, Стандарт, Бизнес
        public string CarImage { get; set; } // Твое поле для картинки машины
        
        // Foreign Key
        public long BrandId { get; set; }
        public virtual Brand Brand { get; set; }
    }
}