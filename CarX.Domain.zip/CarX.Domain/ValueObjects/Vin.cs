namespace CarX.Domain.ValueObjects;

public class Vin
{
    
}