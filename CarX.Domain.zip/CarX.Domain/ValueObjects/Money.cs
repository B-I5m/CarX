namespace CarX.Domain.ValueObjects;

// Value Object должен быть неизменяемым (immutable)
public record Money(decimal Amount, string Currency = "RUB")
{
    public static Money Zero() => new(0);
}